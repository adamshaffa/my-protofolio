$(document).ready(function() {
    // Header fixed on scroll
    var mastheadheight = $('.ds-header').outerHeight();
    $(".ds-banner").css("margin-top", mastheadheight);

    $(window).scroll(function() {
        if ($(window).scrollTop() > 10) {
            $('.ds-header').addClass('ds-fixed-header');
        } else {
            $('.ds-header').removeClass('ds-fixed-header');
        }
    }).scroll();

    // Initialize AOS animations
    AOS.init({ duration: 1000, once: true });
});
